MiniConsole = {}
function MiniConsole:print(...)
    local args = {...}

    local charLimit = 7995
    local str = ""
    for i = 1,#args do
        str = str .. args[i]
    end

    local p1,p2,n = 1-charLimit,0,#str
    while (true) do
        p1,p2 = p1+charLimit,p2+charLimit
        local s = string.sub(str,p1,p2)
        print(s)
        if (p2>=n) then
            break 
        end
    end
    return ErrorCode.OK
end
function MiniConsole:printE(...)
    local args = {...}

    local charLimit = 7995
    local str = ""
    for i = 1,#args do
        str = str .. args[i]
    end

    local p1,p2,n = 1-charLimit,0,#str
    while (true) do
        p1,p2 = p1+charLimit,p2+charLimit
        local s = string.sub(str,p1,p2)
        error(s)
        if (p2>=n) then
            break
        end
    end
    return ErrorCode.OK
end
function MiniConsole:pingChannel(channelName)
    local data = JSON:encode({cmd = "pingChannel", channelName = channelName})
    print("MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&")
end
function MiniConsole:printOnChannel(...)
    local args = {...}

    local charLimit = 7995-30
    local channelName = args[1]

    local str = ""
    for i = 2,#args do
        str = str .. args[i]
    end

    local p1,p2,n = 1-charLimit,0,#str
    while (true) do
        p1,p2 = p1+charLimit,p2+charLimit
        local s = string.sub(str,p1,p2)
        local data = JSON:encode({cmd = "printOnChannel", channelName = channelName, content = s})
        print("MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&")
        if (p2>=n) then
            break
        end
    end
    return ErrorCode.OK
end
function MiniConsole:raiseError(errid)
    local data = JSON:encode({cmd = "raiseError", errid = errid})
    print("MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&")
    return ErrorCode.FAILED
end
function MiniConsole:notifyGameInfo2Self(title,content)
    local data = JSON:encode({cmd = "notifyGameInfo2Self", title = title, content = content})
    local cmd = "MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&"
    if (#cmd > 7999) then
        return MiniConsole:raiseError("CS1012")
    end
    print(cmd)
    return ErrorCode.OK
end
function MiniConsole:createFile(path)
    local data = JSON:encode({cmd = "createFile", path = path})
    local cmd = "MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&"
    if (#cmd > 7999) then
        return MiniConsole:raiseError("CS1012")
    end
    print(cmd)
    return ErrorCode.OK
end
function MiniConsole:addNewTextLine2File(path,content)
    local data = JSON:encode({cmd = "addNewTextLine2File", path = path, content = content})
    local cmd = "MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&"
    if (#cmd > 7999) then
        return MiniConsole:raiseError("CS1012")
    end
    print(cmd)
    return ErrorCode.OK
end
function MiniConsole:closeFile(path)
    local data = JSON:encode({cmd = "closeFile", path = path})
    local cmd = "MiniConsole_dispatchCusEvent2Console^%^&^%^&"..data.."^%^&^%^&"
    if (#cmd > 7999) then
        return MiniConsole:raiseError("CS1012")
    end
    print(cmd)
    return ErrorCode.OK
end